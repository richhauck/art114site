<?php
// check honeypot named "timezone"
if($_POST['timezone'] == '' && (!empty($_POST['email']) || !empty($_POST['subject']) || !empty($_POST['message']))){
	$to = "youremail@yourwebsite.com";
	$subject = stripslashes($_POST['subject']);
	$body = stripslashes($_POST['message']);
	$header = "From: <" . $_POST['email'] . ">\n";
	$header .= "Reply-To: <" . $_POST['email'] . ">\n";
	$header .= "X-Mailer: PHP/" . phpversion() . "\n";
	if(@mail($to, $subject, $body, $header)){
		header('thanks.html');
	} else {
		echo "error";
	}
} else {
	echo "invalid";
}
?>
